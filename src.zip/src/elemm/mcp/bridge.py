import asyncio
import logging
import json
import re
from typing import List, Dict, Any, Optional
import mcp.types as types
from mcp.server import Server
from ..core.context import landmark_ctx, session_headers
from .manifest import ManifestGenerator

logger = logging.getLogger("elemm-bridge")

class LandmarkBridge:
    """Elemm Protocol v1.0 Gateway: Discovery, Inspection, and Execution."""
    
    def __init__(self, manager: Optional[Any] = None, base_url: str = "http://localhost:8001", server_name: str = "elemm-bridge"):
        self.manager = manager
        self.base_url = base_url
        self.server_name = server_name
        self.server = Server(server_name)
        self.manifest = ManifestGenerator(manager)
        self.history = [] # Global result history for piping
        
        self._setup_server()

    def _setup_server(self):
        @self.server.list_tools()
        async def handle_list_tools() -> List[types.Tool]:
            return [
                types.Tool(
                    name="get_landmarks",
                    description="Get the map of namespaces (landmarks) and their objectives.",
                    inputSchema={"type": "object", "properties": {}}
                ),
                types.Tool(
                    name="get_manifest",
                    description="Get the FULL manifest with ALL tool signatures across ALL landmarks in one call.",
                    inputSchema={"type": "object", "properties": {}}
                ),
                types.Tool(
                    name="inspect_landmark",
                    description="Get detailed tool signatures for a specific landmark.",
                    inputSchema={
                        "type": "object", 
                        "properties": {"landmark_id": {"type": "string"}},
                        "required": ["landmark_id"]
                    }
                ),
                types.Tool(
                    name="execute_sequence",
                    description="Execute a chain of tools. Use $N.field to pipe results (e.g. $0.hostname).",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "actions": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "action": {"type": "string", "description": "The ID of the tool to execute."},
                                        "parameters": {"type": "object", "description": "Arguments for the tool."}
                                    },
                                    "required": ["action"]
                                }
                            }
                        },
                        "required": ["actions"]
                    }
                )
            ]

        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: dict) -> List[types.TextContent]:
            try:
                # Normalization (remove landmark prefixes)
                name = name.split(":")[-1].split(".")[-1].strip()
                
                # 1. CORE Tools
                if name == "get_landmarks":
                    return [types.TextContent(type="text", text=self.manifest.generate_summary())]
                
                if name == "get_manifest":
                    return [types.TextContent(type="text", text=self.manifest.generate_full())]
                
                if name == "inspect_landmark":
                    lid = arguments.get("landmark_id") or arguments.get("landmark_ids")
                    return [types.TextContent(type="text", text=self.manifest.generate_landmark_detail(lid))]
                
                if name == "execute_sequence":
                    actions = arguments.get("actions", [])
                    return await self._handle_execute_sequence(actions)
                
                # 2. Normal Actions (Direct Call)
                res_text = await self._execute_single(name, arguments)
                self.history.append(self._parse_result(res_text))
                return [types.TextContent(type="text", text=res_text)]
            except Exception as e:
                logger.exception(f"Tool execution failed: {e}")
                return [types.TextContent(type="text", text=f"Critical Error: {str(e)}")]

    async def _handle_execute_sequence(self, actions: List[Dict]) -> List[types.TextContent]:
        results = []
        local_results = {} # Index -> Result Obj for this turn
        failed_steps = set()  # Track which step indices failed
        
        for i, act in enumerate(actions):
            raw_aid = act.get("action", "") or act.get("action_id", "")
            params = act.get("parameters", {})
            
            # Normalization and Param Extraction from String
            aid = raw_aid.strip()
            
            # If agent sends tool(param=val)
            if "(" in aid and ")" in aid:
                inner = aid[aid.find("(")+1 : aid.rfind(")")]
                aid = aid[:aid.find("(")]
                for kv in inner.split(","):
                    if "=" in kv:
                        k, v = kv.split("=", 1)
                        params[k.strip()] = v.strip().strip("'").strip('"')
            
            if ":" in aid: aid = aid.split(":")[-1].strip()
            if "." in aid: aid = aid.split(".")[-1].strip()
            
            # Check if this step depends on a failed step via piping
            if self._depends_on_failed(params, failed_steps):
                results.append(f"Step {i} ({aid}): SKIPPED (depends on failed Step {self._get_failed_dep(params, failed_steps)})")
                local_results[i] = {"status": "error"}
                failed_steps.add(i)
                continue
            
            # 1. Check for CORE Tools within sequence
            if aid in ["inspect_landmark", "get_landmarks"]:
                if aid == "get_landmarks":
                    res_text = self.manifest.generate_summary()
                else:
                    lid = params.get("landmark_id")
                    res_text = self.manifest.generate_landmark_detail(lid)
                res_obj = res_text
            else:
                # 2. Resolve Magic Piping for normal tools
                resolved_params, pipe_error = self._resolve_params(params, local_results)
                
                if pipe_error:
                    results.append(f"Step {i} ({aid}): FAILED. {pipe_error}")
                    local_results[i] = {"status": "error"}
                    failed_steps.add(i)
                    continue
                
                # 3. Execute Normal Action
                res_text = await self._execute_single(aid, resolved_params)
                res_obj = self._parse_result(res_text)
            
            # 4. Format and Store
            formatted_res = self._format_result(aid, res_text)
            local_results[i] = self._parse_result(res_text)
            self.history.append(local_results[i])
            
            # Track failures
            if isinstance(local_results[i], dict) and local_results[i].get("status") == "error":
                failed_steps.add(i)
            
            results.append(f"Step {i} ({aid}): {formatted_res}")
            
        return [types.TextContent(type="text", text="\n\n".join(results))]

    def _depends_on_failed(self, params: Dict, failed_steps: set) -> bool:
        """Check if params contain $N.field references to any failed step."""
        if not params or not failed_steps:
            return False
        param_str = json.dumps(params)
        for idx in failed_steps:
            if f"${idx}." in param_str:
                return True
        return False

    def _get_failed_dep(self, params: Dict, failed_steps: set) -> int:
        """Get the index of the failed step this depends on."""
        param_str = json.dumps(params)
        for idx in failed_steps:
            if f"${idx}." in param_str:
                return idx
        return -1

    def _format_result(self, tool_name: str, raw_text: str) -> str:
        """Converts raw JSON/text into a clean, human-readable format."""
        try:
            data = json.loads(raw_text)
            if isinstance(data, dict):
                if data.get("status") == "error":
                    msg = data.get("remedy") or data.get("message") or "Unknown error"
                    return f"FAILED. {msg}"
                if len(data) == 1 and "status" in data:
                    return str(data["status"])
                return json.dumps(data)
            return raw_text
        except:
            return raw_text

    def _resolve_params(self, params: Dict, local_results: Dict):
        """Returns (resolved_params, error_string_or_None)."""
        if not params: return {}, None
        param_str = json.dumps(params)
        
        # $0.field -> {{local0.field}}
        param_str = re.sub(r"\$(\d+)\.([a-zA-Z0-9_]+)", r"{{local\1.\2}}", param_str)
        
        placeholders = re.findall(r"\{\{(local|step)?(\d+)\.([a-zA-Z0-9_]+)\}\}", param_str)
        for p_type, idx_str, field in placeholders:
            idx = int(idx_str)
            full_match = "{{" + (p_type or "") + idx_str + "." + field + "}}"
            
            source = local_results if p_type == "local" else self.history
            
            if idx not in source:
                return {}, f"Cannot pipe from Step {idx}: no result available."
            
            data = source[idx]
            val = self._extract_field(data, field)
            
            if isinstance(val, str) and val.startswith("PIPE_ERROR"):
                return {}, val
            
            # Ensure proper JSON encoding for string values
            if isinstance(val, str):
                param_str = param_str.replace(f'"{full_match}"', json.dumps(val))
                param_str = param_str.replace(full_match, val)
            else:
                param_str = param_str.replace(f'"{full_match}"', json.dumps(val))
                param_str = param_str.replace(full_match, str(val))
            
        try:
            return json.loads(param_str), None
        except json.JSONDecodeError as e:
            return {}, f"Piping produced invalid JSON: {e}"

    def _extract_field(self, data: Any, field: str) -> Any:
        if isinstance(data, dict):
            if field in data:
                return data[field]
            available = ", ".join(data.keys())
            return f"PIPE_ERROR: Field '{field}' not found. Available: {available}"
        if isinstance(data, list) and len(data) > 0:
            # Search all items for the field
            for item in data:
                if isinstance(item, dict) and field in item:
                    return item[field]
            # Show what's available in first item
            if isinstance(data[0], dict):
                available = ", ".join(data[0].keys())
                return f"PIPE_ERROR: Field '{field}' not found in list items. Available: {available}"
            return data[0]
        return data

    def _parse_result(self, text: str) -> Any:
        try:
            # Try parsing JSON from text
            # Handle list markers
            clean = text.strip()
            if clean.startswith("- "): clean = clean[2:]
            
            match = re.search(r"(\{.*\}|\[.*\])", clean, re.DOTALL)
            if match:
                return json.loads(match.group(1))
            return clean
        except:
            return text

    async def _execute_single(self, action_id: str, parameters: Dict) -> str:
        """Executes a single action via the manager."""
        action = self.manager.get_action(action_id)
        if not action:
            return f"Error: Tool '{action_id}' not found."
            
        # Set context for auth/headers
        lid = action.groups[0] if action.groups else "root"
        landmark_ctx.set(lid)
        
        try:
            # Use the manager's standardized call logic
            res, status = await self.manager.call_action(action_id, parameters)
            if isinstance(res, (dict, list)):
                return json.dumps(res)
            return str(res)
        except Exception as e:
            return f"Execution Error: {str(e)}"

    def run_stdio(self):
        """Runs the MCP server over STDIO."""
        from mcp.server.stdio import stdio_server
        
        async def main():
            async with stdio_server() as (read, write):
                await self.server.run(
                    read, 
                    write, 
                    self.server.create_initialization_options()
                )
        
        try:
            asyncio.run(main())
        except KeyboardInterrupt:
            pass
